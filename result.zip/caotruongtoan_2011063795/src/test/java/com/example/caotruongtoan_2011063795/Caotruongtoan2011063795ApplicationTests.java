package com.example.caotruongtoan_2011063795;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Caotruongtoan2011063795ApplicationTests {

	@Test
	void contextLoads() {
	}

}
