package com.example.caotruongtoan_2011063795.controller;

import com.example.caotruongtoan_2011063795.entity.Book;
import com.example.caotruongtoan_2011063795.services.BookService;
import com.example.caotruongtoan_2011063795.services.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.Iterator;
import java.util.List;

@Controller
@RequestMapping("/books")
public class BookController {
    @Autowired
    private BookService bookService;

    @Autowired
    private CategoryService categoryService;

    @GetMapping
    public String showAllBooks(Model model){
        List<Book> books = bookService.getAllBooks();
        model.addAttribute("books", books);
        return "book/list";
    }

    @GetMapping("/add")
    public String addBookForm(Model model){
        model.addAttribute("book", new Book());
        model.addAttribute("categories", categoryService.getAllCategories());
        return "book/add";
    }

    @PostMapping("/add")
    public String addBook(@ModelAttribute("book") Book book){
        bookService.addBook(book);
        return "redirect:/books";
    }

    @GetMapping("/edit/{id}")
    public String showUpdateForm(@PathVariable("id") Long id, Model model) {
        Book book = bookService.getBookById(id);

        model.addAttribute("book", book);
        model.addAttribute("category", categoryService.getAllCategories());
        return "Book/edit";
    }
    @PostMapping("/update/{id}")
    public String updateUser(@PathVariable("id") long id, Book book,BindingResult result, Model model) {
        if (result.hasErrors()) {
            book.setId(id);
            return "Book/edit";
        }
        bookService.updateBook(book);
        return "redirect:/books";

    }

    @GetMapping("/delete/{id}")
    public String deleteUser(@PathVariable("id") long id, Model model) {
        Book book = bookService.getBookById(id);
        bookService.deleteBook(book);
        return "redirect:/books";
    }

}
