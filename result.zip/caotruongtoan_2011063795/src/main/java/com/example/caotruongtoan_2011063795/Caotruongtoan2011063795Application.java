package com.example.caotruongtoan_2011063795;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Caotruongtoan2011063795Application {

	public static void main(String[] args) {
		SpringApplication.run(Caotruongtoan2011063795Application.class, args);
	}

}
